
import os
from qgis.utils import iface


import qgis.PyQt as PyQt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QMenu,QAction,QApplication,QDockWidget

from .CommonDashboard import CommonDashboard

def classFactory(iface):
    return CommonPlugin(iface)
    QgsOptionsWidgetFactory

class CommonPlugin:
    def __init__(self, iface=None):
        self.DocksArray = []

    def initGui(self):
        self.Action = QAction('CommonDashboard')
        self.Action.triggered.connect(self.NewDash)
        self.Action.setIcon(QIcon(os.path.dirname(os.path.abspath(__file__))+'/icon.png'))
        iface.addToolBarIcon(self.Action)
        
    def NewDash(self,B):
        Docki = CommonDock(self.DocksArray)
        Dash = CommonDashboard()
        Docki.setWidget(Dash)
        ##Check if QgsProject.instance() has layers
        if Dash.UI['Layers'].count() > 0:
            Dash.LayerSet()
        else:
            Docki.setWindowTitle('Common Dashboard')

        iface.addDockWidget(Qt.RightDockWidgetArea,Docki)
        self.DocksArray.append(Docki)
        
    def unload(self):

        for D in iface.mainWindow().findChildren(QDockWidget):
            if type(D) == CommonDock:
                D.setParent(None)
                D.deleteLater()

        del self.DocksArray
        del self.Action


class CommonDock(QDockWidget):
    def __init__(self,Storage):
        super(CommonDock,self).__init__()
        self.Storage=Storage

    def closeEvent(self, event):
        self.setParent(None)
        self.deleteLater()

        self.Storage.remove(self)
        event.accept()

## QGis Python console commands to help work with live docks
#[i.windowTitle() for i in iface.mainWindow().findChildren(QDockWidget)] ## See all open docks
#iface.mainWindow().findChildren(QDockWidget)[0].findfindChildren(QDialog)[0] ## Get the CommonDashbord instance for the dock
#iface.mainWindow().findChildren(QDockWidget)[0].findfindChildren(QDialog)[0].ShowLayer ##Virtual layer