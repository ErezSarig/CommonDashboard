
import os
from qgis.utils import iface


import qgis.PyQt as PyQt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QMenu,QAction,QApplication,QDockWidget

from .CommonDashboard import CommonDashboard
#from PyQt5.QtWidgets import QMessageBox,QAction,QApplication,QDialog,QLineEdit,QDateEdit, QLabel,QPushButton,QGroupBox,QComboBox,QGridLayout,QFileDialog,QMessageBox

FontName = 'Assistant'
#CSS = '''QLabel,QPushButton{font-weight:bold; } QPushButton{border: 1px solid gray; border-radius:2px} QTabWidget {font-size:14px;font-weight:bold} QGroupBox {font-weight:bold}'''

def classFactory(iface):
    return CommonPlugin(iface)
    QgsOptionsWidgetFactory

class CommonPlugin:
    def __init__(self, iface=None):
        self.DocksArray = []

    def initGui(self):
        ## Getting the QMenuBar instance
        MenuBar = iface.pluginMenu().parentWidget() # QGiS menubar
        self.Action = QAction('CommonDashboard')
        self.Action.triggered.connect(self.NewDash)
        self.Action.setIcon(QIcon(os.path.dirname(os.path.abspath(__file__))+'/icon.png'))
        iface.addToolBarIcon(self.Action)
        
    def NewDash(self,B):
        Docki = QDockWidget()
        
        self.DocksArray.append(Docki)
        Dash = CommonDashboard()
        Docki.setWidget(Dash)
        Docki.setWindowTitle('Common Dashboard')
        Dash.LayerSet()
        iface.addDockWidget(Qt.RightDockWidgetArea,Docki)
        '''Parent = Docki.parentWidget()
        if Parent:
            Docki.setMaximumSize(Parent.minimumSize())
        '''

    def unload(self):
        for D in self.DocksArray:
            del D
        
        del self.Action
