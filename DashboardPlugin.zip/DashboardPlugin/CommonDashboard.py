import qgis
from qgis.utils import iface
from qgis.core import QgsProject,QgsVectorLayer,QgsProjectColorScheme
import qgis.PyQt as PyQt
from qgis.PyQt.QtCore import Qt,QUrl,QByteArray
from qgis.PyQt.QtSvg import QSvgWidget
from qgis.PyQt.QtWidgets import QAction,QApplication,QDialog, QVBoxLayout,QLabel,QPushButton,QGroupBox,QComboBox,QSizePolicy,QCheckBox,QStackedLayout
from qgis.gui import QgsCollapsibleGroupBoxBasic

from tempfile import NamedTemporaryFile
import math
from bs4 import BeautifulSoup,element

def CommonVLayer(Layer, Sql, Name="CommonVLayer"):
    """Query any QGIS layer as a virtual layer named 'Data'."""
    # Construct virtual layer source string
    Provider = Layer.providerType()
    Src = QUrl.toPercentEncoding(Layer.source()).data().decode()

    # The alias "Data" is what you use in the SQL query
    Source = f"?layer={Provider}:{Src}:Data&query={Sql}"
    
    global CommonVL ##^
    CommonVL = QgsVectorLayer(Source, Name, "virtual")

    if not CommonVL.isValid():
        raise Exception(f"Virtual layer query failed:\n{CommonVL.lastError()} \n Query sent: {Source}")
    
    return CommonVL

def GetFillAsCSS(Symbol):
    '''Not tested function to represent QgsSymbols as CSS for polygon fill'''
    if not symbol or symbol.type() != QgsSymbol.Fill:
        return "/* not a fill symbol */"

    css_parts = [f"fill-opacity: {symbol.opacity():.2f};"]

    for layer in symbol.symbolLayers():
        # ---- Simple fill ----
        if isinstance(layer, QgsSimpleFillSymbolLayer):
            css_parts.append(f"fill: {layer.fillColor().name()};")
            css_parts.append(f"stroke: {layer.strokeColor().name()};")
            css_parts.append(f"stroke-width: {layer.strokeWidth()}px;")

        # ---- Line pattern ----
        elif isinstance(layer, QgsLinePatternFillSymbolLayer):
            color = layer.color().name()
            angle = layer.lineAngle()
            dist = layer.distance()
            css_parts.append(
                f"fill: repeating-linear-gradient({angle}deg, "
                f"{color} 0, {color} {dist/2}px, transparent {dist/2}px, transparent {dist}px);"
            )

        # ---- Point pattern ----
        elif isinstance(layer, QgsPointPatternFillSymbolLayer):
            color = layer.color().name() if hasattr(layer, 'color') else "#000"
            dist = layer.distanceX()
            css_parts.append(
                f"fill: repeating-radial-gradient(circle at center, {color} 0, {color} 1px, transparent 1px, transparent {dist}px);"
            )

        # ---- SVG pattern ----
        elif isinstance(layer, QgsSVGFillSymbolLayer):
            svg_path = layer.svgFilePath()
            svg_id = os.path.splitext(os.path.basename(svg_path))[0]
            css_parts.append(f"fill: url(#{svg_id}); /* uses SVG pattern */")

        # ---- Gradient ----
        elif isinstance(layer, QgsGradientFillSymbolLayer):
            color1 = layer.color1().name()
            color2 = layer.color2().name()
            angle = layer.gradientAngle()
            css_parts.append(
                f"fill: linear-gradient({angle}deg, {color1}, {color2});"
            )

        # ---- Shapeburst ----
        elif isinstance(layer, QgsShapeburstFillSymbolLayer):
            color1 = layer.color1().name()
            color2 = layer.color2().name()
            css_parts.append(
                f"fill: radial-gradient(circle, {color1}, {color2});"
            )

        else:
            css_parts.append(f"/* unsupported: {layer.layerType()} */")

    return " ".join(css_parts)

def CommonColors(i=None):
    '''Retriving project colors'''
    
    Colors = QgsProjectColorScheme().fetchColors()
    if i == None:
        return len(Colors)
    C = Colors[i % len(Colors)][0]
    return C.name()
        
def CommonCatSymbol(C,ID=None,Color=False):
    '''Retriving an svg pattern represtenting category's symbol (fill based symbols only)'''
    Size= 60
    if C.symbol().type() == qgis.core.Qgis.SymbolType.Fill and Color == False:  
        with NamedTemporaryFile() as F:
            C.symbol().exportImage(F.name,'svg',QSize(Size,Size))
            Soup = BeautifulSoup(F.read(), 'html.parser') ##Getting the SVG code
            
            ##Cleaning all irelevant tags and comments
            Soup.title.decompose()
            Soup.desc.decompose()
            
            for Line in Soup.contents:
                if type(Line) == element.ProcessingInstruction or Line == '\n':
                    Soup.contents.remove(Line)
                
            ## Extracting the symbol's defs to be added as well
            try:
                Soup.defs.unwrap()
            except:
                pass
                
            Pattern_tag = Soup.new_tag('pattern' ,id=str(ID),x="0",y="0",width=Size,height=Size,patternUnits="userSpaceOnUse")
            Soup.svg.wrap(Pattern_tag)
            Soup.svg.unwrap()
            return Soup.prettify()
            
def CommonPlot(Data,Type='Pie',Dimensions=130,ShowLegend=False,SvgPatterns=[],CSS=''):
    '''
    </h2> C_Plot(Data,Type='Pie',Dimensions=100,SvgPatterns=[],CSS='')</h2>
    <h3> Ploting data to pie or bars charts. Returning svg code to embed where needed
    <br><b>Data</b : JSON object using {"Size": int, "Color":str,"Label":str} like features. use "Color":'Auto' to use project's color scheme
    <br><b>Type</b> : 'Pie'/'Bars' for matching displays
    <br><b>Dimensions</b> : Radius size for pie charts and bar width for bar charts
    <br><b>SvgPatterns</b> : A list of pattern to use for the svg defs section. Enables referncing instead of colors using 'url(#PatternName)'
    <br><b>CSS</b> : Adding any style sheet defintions.
    <br><sub>** Svg's id named #PiePath<Num> are reserved
    '''
    ##+ Add sum label option ('Abs'/'Per'/None) for showing each categorie's size in numbers
    try: ##Going through data to get general properties and check the features are constructed the right way
        Total = 0
        Top = Data[0]['Size']
        Bottom = 0
        for D in Data:
                
            if Top < D['Size']:
                Top = D['Size']
            elif Bottom > D['Size']:
                Bottom = D['Size']
            Total += max(0,D['Size'])
    
    except Exception as Err:
        raise ValueError(f"Expecting attribute named 'Size' with numeric values for all features.Got this error: ",Err)
        
    ColorIndex = 0
    SvgParts= [f'<Style>{CSS}</Style>','<defs>','\n'.join(SvgPatterns),'</defs>']## Adding svg paterns, SVG openning tag will be added acording to chart type
    
    if Type.casefold() == 'pie':
        LineH =20 ##+Get font-size from CSS 
        VBox = [0,0,2*(Dimensions+LineH+2),2*(Dimensions+LineH)]
        SvgParts.append(f'<g transform="translate({Dimensions+LineH},{Dimensions+LineH})">')
        Start = 0 #Starting angle
        
    elif Type.casefold() == 'bars':
        X = 0
        Start= Top*300/(Top-Bottom)
        VBox = [0,0,(Dimensions+2)*len(Data),300]
        
    if ShowLegend: ##Adding space at the end of the image
        VBox[3] += len(Data)* 25
    
    ##Adding svg tag after calculating view box
    SvgParts.insert(0,f'''<svg ViewBox="{' '.join(list(map(str,VBox)))}" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1">''')
    #print(Data)
    for i,D in enumerate(Data):
        if 'Color' in D.keys() and type(D['Color']) == str and 'Label' in D.keys() and type(D['Label']) == str:
            if 'url' in D['Color'].casefold() and len(SvgPatterns) == 0: ## for wrong input cases
                D['Color'] = 'Auto'
                
            if D['Color'].casefold() == 'auto' :
                        D['Color'] = CommonColors(ColorIndex)
                        ColorIndex +=1
                
            if Type.casefold() == 'Pie'.casefold():
                if D['Size'] < 0:
                    raise ValueError(f"Pie charts aren't suppose to deal with negative values like the one given on feature number {i}")
                elif D['Size'] > 0:
                    
                    Normal = D['Size'] / Total #Normalized value
                    InnerLabel = '{:.1%}'.format(Normal)
                    
                    End = Start + 360 * Normal
                    x1 = Dimensions*math.cos(math.radians(1-Start))
                    y1 = Dimensions*math.sin(math.radians(1-Start))
                    x2 = Dimensions*math.cos(math.radians(1-End))
                    y2 = Dimensions*math.sin(math.radians(1-End))
                    LabelX = Dimensions*0.7*math.cos(math.radians(1-Start-180*Normal))
                    LabelY = Dimensions*0.7*math.sin(math.radians(1-Start-180*Normal))
                    Large_arc = 1 if End - Start > 180 else 0
                    Path_d = f"M0,0 L{round(x1,1)},{round(y1,1)} A{Dimensions},{Dimensions} 0 {Large_arc},0 {round(x2,1)},{round(y2,1)} Z"
                    LineW = min(round(D['Size']/Total* Dimensions*6.28),len(D['Label'])*20*4) #Estimating for lengthAdjustment
                    SvgParts.append(f'''<path class="Polygons" d="{Path_d}" fill="{D['Color']}"/>''')
                    if not ShowLegend:
                        #SvgParts.append(f'''<text class="Labels" dy="0.9em"><textPath href="#PiePath{i}" lengthAdjust="spacingAndGlyphs" startOffset="{Dimensions}" textLength="{LineW}">{D['Label']}</textPath></text>''')
                        SvgParts.append(f'''<text classs="Labels" x="1em" text-anchor="start" transform="rotate({360-Start} 0 0) translate(10 -3)" stroke-width="0.18" startOffset="1em" textLength="{Dimensions}" lengthAdjust="spacingAndGlyphs" >{D['Label']}</text> ''')
                    SvgParts.append(f'''<text class="InnerLabels" fill="white" text-anchor="middle" font-size="0.7em" x="{round(LabelX)}" y="{round(LabelY)}"> {InnerLabel}</text>''')
                    Start = End
                    
            elif Type.casefold() == 'Bars'.casefold():
                
                InnerLabel = '{:,}'.format(D['Size'])
                Direction = -1 if D['Size'] <0 else 1 
                Normal = round(D['Size']*300/(Top -Bottom),1) #Normalizing values
                LineH =22*Direction ##+Get font-size from CSS 
                        
                SvgParts.append(f'''<rect class="Polygons" x="{X}" y="{Start-max(Normal,0)}" width="{Dimensions}" height="{abs(Normal)}" fill="{D['Color']}"/>''')
                if not ShowLegend:
                    SvgParts.append(f'''<text class="Labels" x="round({round(X+10)}" y="{Start-3}" stroke-width="0.18" transform="rotate(270 {round(X+10)} {Start-3})" textLength="{min(Top,len(D['Label'])*LineH)}" lengthAdjust="spacingAndGlyphs"> {D['Label'] }</text>''')
                SvgParts.append(f'''<text class="InnerLabels" text-anchor="middle" fill="white" font-size="0.7em" x="{X+(0.5*Dimensions)}" y="{Start-3}"> {InnerLabel}</text>''')
                X += Dimensions + 2
            else:
                raise ValueError("Expecting 'Bars' or 'Pie' on Type variable (2nd)")
    
        else:
            raise ValueError("Data must be a json constructed from 'Size','Color' and 'Label' keys as strings even if empty")
            
    if Type.casefold() == 'Pie'.casefold():
        SvgParts.append('</g>')
    
    
    ##Adding leegend
    if ShowLegend:
        SvgParts.append(f'<g transform="translate(0 {VBox[3] - len(Data)* 25 +5})" id="Legend">')
        for i,D in enumerate(Data):
            SvgParts.append(f'''<rect x="0" transform="translate(0 {i*25})" height="20" width="20" fill="{D['Color']}"/>''')
            SvgParts.append(f'''<text x="25" y="10" transform="translate(0 {i*25})"> {D['Label']}</text>''')
            
        SvgParts.append('</g>')
    SvgParts.append('</svg>')
    return '\n'.join(SvgParts)

class CommonDashboard(QDialog):
    def __init__(self):
        super(CommonDashboard,self).__init__()
        #self.parentWidget().setWindowTitle('Common Dashboard')
        #self.setLayoutDirection(QtCore.Qt.RightToLeft)
        self.L = iface.activeLayer()
        #self.setWindowOpacity(0.8)
        self.Lay = QVBoxLayout(self)
        self.UI = dict()
        
        self.UI['Settings'] = QgsCollapsibleGroupBoxBasic()
        self.UI['Settings'].setTitle('Choose a layer:')
        ##+ Find the way to make svg resize to max and settings lines to always be minimum
    
        self.SettingsL = QVBoxLayout(self.UI['Settings'])
        self.UI['LayersLabel']=QLabel('Choose a layer to group:')
        self.UI['Layers'] = QComboBox()
        
        self.UI['GroupByLabel']=QLabel('Group features by :')
        self.UI['GroupBy'] = QComboBox()
        
        self.UI['SumTypeLabel']=QLabel('Sum features by :')
        self.UI['SumType'] = QComboBox()
        
        self.UI['ChartTypeLabel'] = QLabel('Chart type:')
        self.UI['ChartType'] = QComboBox()
        sizePolicy = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)
        
        self.UI['ShowLegend'] = QCheckBox('Add legend')
        self.UI['ShowLegend'].setChecked(True)
        
        self.UI['Visual'] = QGroupBox()
        self.VisualL = QVBoxLayout(self.UI['Visual'])
        self.UI['Image'] = QSvgWidget()
        self.UI['ExportSVG'] = QPushButton('Export as Svg')
        
        Layout = self.Lay
        for O in list(self.UI.values()):
            if type(O) == PyQt.QtWidgets.QGroupBox or O == self.UI['Settings']:
                self.Lay.addWidget(O)
                Layout = O.layout()
            else:
                Layout.addWidget(O)
                
        for L in QgsProject.instance().mapLayers().values():
            if type(L) ==  qgis.core.QgsVectorLayer and L.source()[0:6] != 'memory': ##Listing only vector layer and no temp layer
                self.UI['Layers'].insertItem(0,L.name())
                
        self.UI['Layers'].setCurrentText(self.L.name())
        
        self.UI['SumType'].insertItem(0,'Amount')
        
        self.UI['ChartType'].insertItems(0,['Pie','Bars'])
        
        self.UI['GroupBy'].currentIndexChanged.connect(self.GroupSet) 
        self.UI['Layers'].currentIndexChanged.connect(self.LayerSet)
        self.UI['SumType'].currentIndexChanged.connect(self.CleanData)
        self.UI['Settings'].collapsedStateChanged.connect(self.ShowSVG)
        self.UI['ExportSVG'].clicked.connect(self.Export)
        '''Calculations only triggered when settings group is collapsed or export is clicked'''
    def LayerSet(self):
            
        self.L = QgsProject.instance().mapLayersByName(self.UI['Layers'].currentText())[0]
        self.L.afterCommitChanges.connect(self.LayerSet) ## Refreshing data when layer is cahnged
        self.FieldsList = []

        self.UI['Settings'].setTitle(self.UI['Layers'].currentText())

        self.UI['GroupBy'].clear()
        self.UI['SumType'].clear()
        try:
            self.UI['SumType'].currentIndexChanged.disconnect()
            self.UI['GroupBy'].currentIndexChanged.disconnect()
        except:
            pass

        if self.L.featureCount() > 0:
            ## Filling summing options. using layer's numeric fields or dimensions according to geometry type
            NumFields = [F.name() for F in self.L.fields() if F.isNumeric()] #To allow summing of otheer fields
            self.UI['SumType'].insertItems(self.UI['SumType'].count(),NumFields)
            self.UI['SumType'].insertSeparator(0)
            
            if self.L.geometryType() == qgis.core.Qgis.GeometryType.Line:
                self.UI['SumType'].insertItem(0,'Length')
            elif self.L.geometryType() == qgis.core.Qgis.GeometryType.Polygon:
                self.UI['SumType'].insertItem(0,'Area')
            
            self.UI['SumType'].insertItem(0,'Amount')
            self.UI['SumType'].setCurrentIndex(0)
            self.UI['SumType'].currentIndexChanged.connect(self.CleanData)
            
            ## Filling grouping options. using layer's fields or styling categories
            
            self.FieldsList = [F.name() for F in self.L.fields()]
            self.UI['GroupBy'].insertItems(0,self.FieldsList)
            if type(self.L.renderer()) == qgis._core.QgsCategorizedSymbolRenderer:
                self.UI['GroupBy'].insertSeparator(0)
                self.UI['GroupBy'].insertItem(0,'Layer categories')
                self.UI['GroupBy'].setCurrentIndex(0)
                if self.L.renderer().classAttribute().strip('"') not in [F.name() for F in self.L.fields()]: #Varifying 
                    self.UI['GroupBY'].model().item(0).setEnabled(False)
            self.UI['GroupBy'].currentIndexChanged.connect(self.GroupSet)
            self.GroupSet()

        else:
            self.UI['GroupBy'].insertItem(0,'Layer is empty')
            self.GB = None
            self.CleanData()

    def GroupSet(self):
        if self.UI['GroupBy'].currentText() == 'Layer categories':
            self.GB = self.L.renderer().classAttribute().strip('"') #In case an expression was used to refernce a legit field name
        elif len(self.UI['GroupBy'].currentText()) > 0:
            self.GB = self.UI['GroupBy'].currentText()
        else:
            self.GB = None
            
        self.CleanData()
        
    def CleanData(self):
        self.Data = []
        
    def GetData(self):
        R = self.L.renderer()
        ## Categories made by field with no Qgs expressions
        if self.GB != None:
            if self.UI['SumType'].currentText() == 'Amount':
                Sql = f"SELECT {self.GB},COUNT(*) as Sum FROM Data"
            elif self.UI['SumType'].currentText() == 'Length':
                Sql = f"SELECT {self.GB},sum(st_length(geometry)) as Sum FROM Data"
            elif self.UI['SumType'].currentText() == 'Area':
                Sql = f"SELECT {self.GB},sum(st_area(geometry)) as Sum FROM Data"
            else:
                Sql = f"SELECT {self.GB},sum({self.UI['SumType'].currentText()}) as Sum FROM Data"
            
            Sql += f' GROUP BY {self.GB} ORDER BY SUM DESC;'
            #print(Sql) ##^
            VL = CommonVLayer(self.L,Sql)
            self.ShowLayer = VL ##^
            #QgsProject.instance().addMapLayer(VL) ##^
    
            ## Constructing the Data dict to use with CommonPlot
            ## Creating 'All others' in data
            self.Data =[]
            if self.UI['GroupBy'].currentText() == 'Layer categories' and None in list(map(lambda x: x.value(),R.categories())): # For already defined all others category
                Line = {'Size':0
                    ,'Label':R.categories()[list(map(lambda x: x.value(),R.categories())).index(None)].label()  
                    ,'Color':f'url(#{str(R.categoryIndexForValue(None))})'
                    }
            else: # Creating an all other category
                Line = {'Size':0,'Label':'All others','Color':'Transparent'}
            self.Data.append(Line)
            
            ## Constructing the Data to fit CommonPlot structure
            for F in VL.getFeatures():
                Att = F.attribute(self.GB) #Category value
                
                if self.UI['GroupBy'].currentText() == 'Layer categories':
                    CatIndex = R.categoryIndexForValue(Att)
                else:
                    CatIndex = None 
                
                Line = dict()
                if CatIndex== None and len(self.Data) < CommonColors(): ## Adding new category from data
                    Line['Size'] = round(F.attribute('Sum'),1)
                    Line['Label'] = str(Att)
                    Line['Color'] = 'Auto'
                    self.Data.append(Line)
                    
                elif CatIndex != None and CatIndex > -1: ## Matching with a layer's category 
                    #print(CatIndex) ##^
                    Line['Size'] = round(F.attribute('Sum'),1) 
                    Line['Label'] = R.categories()[CatIndex].label()
                    Line['Color'] = f'url(#{CatIndex})'
                    self.Data.append(Line)
                else: ## if categories are taken from layer and no matching category found
                    self.Data[0]['Size'] += round(F.attribute('Sum'),1)
                    
            if self.Data[0]['Size'] == 0:
                self.Data.pop(0) #Only if All Others line was created artifically
                
    def Export(self):
        R = self.L.renderer()
        Patterns = dict()
        if len(self.Data) == 0 :
            self.GetData()
            
        if self.UI['GroupBy'].currentText() == 'Layer categories':
            for C in R.categories():
                Patterns[str(C.value())] = CommonCatSymbol(C,R.categoryIndexForValue(C.value()))
        
        if len(self.Data) == 0 :
            Path =  QFileDialog().getSaveFileName(None,"Save SVG:",'',"SVG (*.svg)")[0]

            if Path:
                self.SVG = QByteArray(CommonPlot(self.Data,self.UI['ChartType'].currentText(),ShowLegend=self.UI['ShowLegend'].isChecked(),SvgPatterns=Patterns.values()).encode('utf-8')) #Decode string from commonPlot for use on QSVGWidget
                     
                with open(Path,'wb') as F:
                    F.write(self.SVG.data())
                
    def ShowSVG(self): ## A separate svg creation with no patterns until Qt6 will be in
        R = self.L.renderer()
        Patterns = dict()
        if len(self.Data) == 0 : 
            self.GetData() ## Building new data after user change in settings

        if len(self.Data) > 0 and self.UI['Settings'].isCollapsed():
            ## Undoing patterns for Qt5 limited svg abilities
            for D in self.Data:
                if 'url' in D['Color'].casefold():
                    #print(D['Color']) ##^
                    if 'None' in D['Color']:
                        CatIndex = list(map(lambda x:x.value(),R.categories())).index(None)
                    else:
                        CatIndex = int(D['Color'][D['Color'].find('#')+1 : D['Color'].find(')')])
                    try:    
                        Cat = R.categories()[CatIndex]
                        D['Color'] = Cat.symbol().color().name()
                    except:
                        pass
                        
            self.SVG = QByteArray(CommonPlot(self.Data,self.UI['ChartType'].currentText(),ShowLegend=self.UI['ShowLegend'].isChecked()).encode('utf-8')) #Decode string from commonPlot for use on QSVGWidget
            
            self.UI['Image'].load(self.SVG)
            self.UI['Image'].show()
        
        else:
            self.UI['Image'].hide()
    
